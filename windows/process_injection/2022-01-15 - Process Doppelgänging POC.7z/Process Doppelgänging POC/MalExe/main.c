#include <stdio.h>
#include <Windows.h>

int main(void)
{
	//__asm int 3;
	MessageBox(0, "Message body", "Message title", MB_OK);
}