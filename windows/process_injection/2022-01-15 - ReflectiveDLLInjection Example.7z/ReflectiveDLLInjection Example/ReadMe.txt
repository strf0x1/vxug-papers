Save ReflectiveDLLInjection to load dll no need to call loadlibrary.

https://github.com/stephenfewer/ReflectiveDLLInjection