//
// Copyright (c) Johnny Shaw. All rights reserved.
// 
// File:     source/ProcessHerpaderping/res/resource.h
// Author:   Johnny Shaw
// Abstract: Resource Header 
//
#define IDI_ICON                        101
