
#include <Common.h>
#include <Ekko.h>

int main(  )
{
    puts( "[*] Ekko Sleep Obfuscation by C5pider" );

    do
        // Start Sleep Obfuscation
        EkkoObf( 4 * 1000 );
    while ( TRUE );

    return 0;
}