
# Ekko

A small sleep obfuscation technique that uses `CreateTimerQueueTimer` to queue up the ROP chain that performs Sleep obfuscation

### Credit
- [Austin Hudson (@SecIdiot)](https://twitter.com/ilove2pwn_) https://suspicious.actor/2022/05/05/mdsec-nighthawk-study.html
