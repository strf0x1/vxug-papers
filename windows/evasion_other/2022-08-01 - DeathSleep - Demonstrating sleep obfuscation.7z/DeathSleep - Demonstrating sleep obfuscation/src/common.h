#ifndef COMMON_H
#define COMMON_H

#include <windows.h>
#include <stdio.h>

#endif