# StackCrypt
Create a new thread that will suspend every thread and encrypt its stack, then going to sleep , then decrypt the stacks and resume threads

### Video

https://user-images.githubusercontent.com/123980007/234462390-02ac980f-b924-478a-b4f3-b707451fb2df.mp4


