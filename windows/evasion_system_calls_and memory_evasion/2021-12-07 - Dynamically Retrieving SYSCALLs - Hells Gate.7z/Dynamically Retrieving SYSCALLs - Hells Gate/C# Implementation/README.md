## C# Hell's Gate ##
C# Implementation of the Hell's Gate VX Technique 
<br />
<br />
Link to the paper: https://vxug.fakedoma.in/papers/VXUG/Exclusive/HellsGate.pdf
<br /> PDF also included in this repository.
<br />
<br />
Link to the original C implementation: https://github.com/am0nsec/HellsGate
<br />
<br />
