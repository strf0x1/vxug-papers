## Hell's Gate ##

Original C Implementation of the Hell's Gate VX Technique
<br />
<br />
Link to the paper: https://vxug.fakedoma.in/papers/hells-gate.pdf
<br /> PDF also included in this repository.
<br />
<br />
Authors:
* Paul Laîné (@am0nsec)
* smelly__vx (@RtlMateusz)
<br />

### Update  ###
Please note:
* We are not claiming that this is ground-breaking as many people have been using this kind of technique for many years;
* We are not claiming that this is the perfect and most optimised way to archive the objective. This is just one example on how to implementation the technique;
* Judging the idea/technique/project/research solely on the name is petty to say the least and definitively childish; and
* Any recommendation and/or ideas will always be welcome, just open an issue in this repository.

