#pragma once
#include "Windows.h"

void TestLocateFunctionByAddress();
void TestLookupByFrameOffset();
void TestEnumAllRT(DWORD);
void Test();