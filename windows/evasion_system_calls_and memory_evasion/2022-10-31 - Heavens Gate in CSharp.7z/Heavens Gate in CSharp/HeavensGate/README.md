# HeavensGate

This directory is for Heaven's Gate technique.

## HeavensGatePoC

[Project](./HeavensGatePoC)

this PoC tries to call `NtQueryInformationProcess` with Heaven's Gate technique.