HideProcess by Remove ProcessList in EPROCESS struct.
Support Windows xp and windows 7 OS, you can add other os's offset of ProcessList in EPROCESS to support more.