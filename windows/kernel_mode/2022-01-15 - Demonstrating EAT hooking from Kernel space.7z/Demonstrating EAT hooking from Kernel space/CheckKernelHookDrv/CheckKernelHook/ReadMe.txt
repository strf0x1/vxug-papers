Check Kernel EAT Hook
