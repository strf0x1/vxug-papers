#include "stdafx.h"

BOOL Release();
BOOL UnloadDrv(TCHAR* DriverName);
BOOL LoadDrv(TCHAR* DriverName);