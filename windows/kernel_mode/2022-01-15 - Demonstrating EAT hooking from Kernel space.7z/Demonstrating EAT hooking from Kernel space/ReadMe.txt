1.Reload the first kernel module
2.check EAT function (Zwxx) 
3.check InlineHook (not Zwxx)
