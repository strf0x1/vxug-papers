# Terminator

* Reproducing Spyboy technique to terminate all EDR/XDR/AVs processes
* Spyboy sells the software for prices ranging from $300 for a single bypass to $3,000 for an all-in-one bypass [for more detail](https://www.bleepingcomputer.com/news/security/terminator-antivirus-killer-is-a-vulnerable-windows-driver-in-disguise/)
* the sample is sourced from [loldrivers](https://www.loldrivers.io/drivers/49920621-75d5-40fc-98b0-44f8fa486dcc/)
# usage

* Place the driver `Terminator.sys` in the same path as the executable
* run the program as an administrator
* keep the program running to prevent the service from restarting the anti-malwares

  ![image](https://github.com/ZeroMemoryEx/Terminator/assets/60795188/81160d04-95e2-48e8-9f2f-177a2757762e)
