
* place the driver in the same directory as the executable, and run the executable as an administrator.
