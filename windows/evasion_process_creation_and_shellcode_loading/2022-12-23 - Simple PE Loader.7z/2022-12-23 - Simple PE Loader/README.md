# Simple_PE_Loader
⚙️ Default PE loader on C++. Only x86 Native is supported. It's not hard to redo for x64, whoever needs it will do it. Copies the table of imports, sections, and relocations. !!! For the loader to work, the payload must have a .reloc section

I do not advise you to be a script-kiddy, who does not understand - study :)

# How to use

1. Put the contents of your file in Payload.h (you can use HxD Editor)
2. Compile the program and rejoice

# Example
![Example](https://github.com/reverserb/Simple_PE_Loader/blob/main/Screenshot.png?raw=true "Example")
