Sometimes you need to transfer your files over the proxy/DLP/gateway etc. Or just demonstrate the possibility.

I bypassed such protection multiple times with Base64, but then realized some DLPs look at the text trying to asses the string entropy, finding common english words etc.
So I have created new pair of scripts (bin2word / word/2bin), describing the arbitrary file in a nicer way, totally "safe" for all those peeking inside.

Couple of years later, I made something different: a script exfiltrating the file via audio, and another one for re-creating the file from the sound recorded. Enjoy, and feel free to modify, especially if you can improve analysis performance :P

Feel free to use. It is kind of PoC, but it works nicely.

