﻿namespace TeamServer.Models
{
    public class ImplantTaskOut
    {
        public string Id { get; set; }
        public string TaskName { get; set; }
        public string TaskArgs { get; set; }
        public string TaskOut { get; set; }
    }
}
