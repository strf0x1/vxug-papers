﻿using System.Collections.Generic;

namespace Implant.Models
{
    public class ImplantTaskData
    {
        public static readonly List<ImplantOptions> _opts = new List<ImplantOptions>();
    }
}
