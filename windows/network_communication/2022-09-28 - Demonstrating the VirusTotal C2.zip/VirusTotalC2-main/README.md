# VirusTotalC2
Abusing VirusTotal API to host our C2 traffic, usefull for bypassing blocking firewall rules if VirusTotal is in the target white list , and in case you don't have C2 infrastructure , now you have a free one


# usage  
## Upload a file in VirusTotal UI, get the file Hash , u need also the API key after creating an account  
## Implant/TeamServer.exe {file Hash}    
## be aware of the day's comments quota for the free API.  

https://user-images.githubusercontent.com/110354855/192811979-f9beb0b8-c0cd-42d0-bd48-29b86a6775a4.mp4
