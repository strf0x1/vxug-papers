<h1 align="center">
  <br>
  HLeaker
  <br>
</h1>
<h4 align="center">This allows you to use the process handles from services/protected processes like csrss and lsass.</h4>

<p align="center">
<img src="https://img.shields.io/badge/open-source-blue.svg" alt="op">
<img src="https://img.shields.io/aur/license/yaourt.svg" alt="lm">
<a href="https://www.sinhax.tk/donate/donate.html"><img src="https://img.shields.io/badge/donate-bitcoin-orange.svg" alt="dt"></a>
<a href="https://www.paypal.com/cgi-bin/webscr?cmd=_donations&business=aldahirhamad%40gmail%2ecom&lc=BT&item_name=Schnocker&no_note=0&currency_code=EUR&bn=PP%2dDonationsBF%3abtn_donateCC_LG%2egif%3aNonHostedGuest"><img src="https://img.shields.io/badge/donate-paypal-green.svg" alt="dt"></a>
</p>

## Preview

<a href="http://i.imgur.com/mlLWBSU.png" target="_blank">Screenshot</a>

## Compiling

To compile "HLeaker" you need [Visual Studio](https://www.visualstudio.com).

## Downloads

Releases of *HLeaker* can be found [here](https://www.unknowncheats.me/forum/anti-cheat-bypass/212113-hleaker.html).

## License

*HLeaker* is licensed under GPLv3, which means you can freely distribute and/or modify the source of *HLeaker*.
