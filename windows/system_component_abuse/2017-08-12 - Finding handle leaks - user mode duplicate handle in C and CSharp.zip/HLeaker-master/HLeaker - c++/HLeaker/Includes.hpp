#pragma once


#include <Windows.h>
#include <iostream>
#include <map>
#include <Wtsapi32.h>
#include <Userenv.h>
#include <vector>
#include <Psapi.h>
#include <TlHelp32.h>
#pragma comment(lib,"Wtsapi32")
#pragma comment(lib,"Userenv")
#pragma comment(lib,"psapi")