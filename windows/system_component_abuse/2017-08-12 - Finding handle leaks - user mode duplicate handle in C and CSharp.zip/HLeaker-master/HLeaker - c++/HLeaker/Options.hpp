#pragma once

#define TARGET_PROCESS "Unturned.exe"
#define YOUR_PROCESS "HLeaker.exe"

#define DESIRED_ACCESS PROCESS_VM_READ
#define DELAY_TO_WAIT 10

#define OBJECTTIMEOUT 1000
#define USE_DUPLICATE_HANDLE 0